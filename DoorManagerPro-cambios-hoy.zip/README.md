# DoorManager Pro

DoorManager Pro es una plataforma de operaciones para empresas instaladoras y mantenedoras de puertas automáticas. Centraliza SAT, técnicos en campo, comercial, oficina y gerencia en una interfaz responsive orientada a trabajo real y a funcionamiento offline-first.

Web pública: https://doormanager-pro.pages.dev/

## Objetivo

El objetivo del proyecto es construir una aplicación profesional para gestionar partes, equipos, checks técnicos, avisos, materiales, PRL, vehículos, seguros, documentación y actividad comercial con seguridad por roles y preparación para baja cobertura en campo.

## Funciones actuales

- Login público sin accesos demo ni credenciales visibles.
- Sesión protegida en frontend y redirección de rutas privadas al login.
- Dashboards diferenciados para SAT, Comercial, Oficina y Gerencia.
- Espacio Técnico directo a Mi jornada.
- Restricción de partes técnicos a trabajos asignados.
- Checks visuales de puerta seccional industrial con hotspots.
- Guardado local de bloques de check, observaciones, intervención, incidencias y fotografías simuladas.
- Botón Sincronizar manual con cola local de cambios pendientes.
- Avisos con lectura, cierre y navegación al registro relacionado.
- Módulos no completados con página propia en desarrollo, sin redirecciones falsas.
- Diseño responsive con ajustes para móvil, tablet y escritorio.

## Roles

- Técnico: consulta Mi jornada, abre trabajos asignados, registra avance operativo, ejecuta checks y guarda datos localmente.
- SAT: planificación diaria, técnicos, partes, equipos, avisos, checks y material.
- Comercial: oportunidades, presupuestos, contratos, visitas y seguimiento.
- Oficina: facturación, cobros, compras, PRL, personal, vehículos, documentación y seguros.
- Gerencia: ventas, facturación, costes, margen, productividad, garantías y reclamaciones.

## Tecnologías

- React.
- TypeScript.
- Vite.
- CSS responsive propio.
- Persistencia local con `localStorage` para sesión, estado operativo, checks y cola de sincronización.

## Supabase

El repositorio actual no incluye cliente Supabase, migraciones ni políticas RLS aplicables. La aplicación queda preparada a nivel de interfaz para sustituir el acceso local por Supabase Auth y servicios con RLS, pero esa integración debe implementarse antes de usar datos reales.

Variables previstas para Cloudflare Pages cuando se añada Supabase:

```text
VITE_SUPABASE_URL
VITE_SUPABASE_PUBLISHABLE_KEY
```

No debe usarse ninguna clave administrativa en frontend.

## Instalación

```bash
npm install
```

## Desarrollo

```bash
npm run dev:web
```

## Build

```bash
npm run build
```

## Variables De Entorno

Para desarrollo local sin publicar credenciales puede activarse un acceso local temporal:

```text
VITE_LOCAL_AUTH_ENABLED=true
VITE_LOCAL_AUTH_ACCESS_KEY=<valor privado local>
```

Estas variables no deben subirse al repositorio. En producción debe sustituirse por Supabase Auth.

## Offline First

El flujo técnico guarda primero en el dispositivo:

- estado del parte;
- bloques de check;
- componentes;
- observaciones;
- intervenciones;
- incidencias;
- fotografías simuladas;
- cola de sincronización.

La sincronización no se lanza automáticamente al recuperar conexión. El técnico debe pulsar `Sincronizar`.

## Sincronización Manual

El botón `Sincronizar` muestra elementos pendientes y protege contra doble pulsación. Si falla una futura integración remota, no deben borrarse los datos locales hasta confirmar persistencia en backend.

## Estado Del Proyecto

Este repositorio sigue siendo un frontend de prototipo funcional. No contiene backend, base de datos Supabase, Storage, RPC ni RLS. Las protecciones actuales evitan exposición pública de credenciales y corrigen flujos locales críticos, pero no sustituyen la seguridad de backend.

## Limitaciones

- No hay Supabase Auth real en el código actual.
- No hay migraciones ni seed SQL en el repositorio.
- No hay persistencia remota.
- Las fotografías son entradas locales simuladas.
- PRL, vehículos, seguros y materiales usan datos locales de prueba.

## Próximos Pasos

- Integrar Supabase Auth.
- Crear esquema, migraciones nuevas, seeds y políticas RLS.
- Implementar servicios reales por rol.
- Mover códigos automáticos a base de datos o RPC segura.
- Sustituir fotografías simuladas por IndexedDB y Supabase Storage.
- Validar con pruebas end-to-end en móvil real.
